class UsersController < ApplicationController
  def index
    @Users = User.all()
  end

  def new
    render "/users/new"
  end

  def create
    bError = false

    user  = User.new

    user.first_name =
    user.first_name = params[:first_name]
    user.last_name = params[:last_name]
    user.email_address = params[:email_address]

    if user.save()
      redirect_to '/users'
    else

      flash[:alert] = []

      user.errors.each do |attr, msg|
        flash[:alert].insert(-1, "#{attr}: #{msg}")
      end

      render "/users/new"

    end

  end


end
